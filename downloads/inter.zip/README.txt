Inter — Hausschrift der Verkehrskadetten
========================================

Inter ist die Hausschrift für alle Anwendungen (Web, Print, Dokumente).
Die Logo-Schriftmarke basiert weiterhin auf «Fakt» und ist in den Logo-
Dateien fest hinterlegt — Fakt wird nicht mehr für Text verwendet.

Enthaltene Schnitte (Ordner OTF für InDesign/Illustrator, TTF für Office/Windows)
--------------------------------------------------------------------------------
- Inter Light (300)   — Claim, ruhiger Fliesstext        (+ Light Italic)
- Inter Regular (400) — Fliesstext                        (+ Italic)
- Inter Bold (700)    — Schriftmarke, Titel, Slogans      (+ Bold Italic)

Italic wird punktuell für Betonungen und Zitate eingesetzt.

Installation
------------
- macOS:   Doppelklick auf die Schriftdatei → «Installieren» (Schriftsammlung).
- Windows: Rechtsklick auf die Schriftdatei → «Installieren».
  Für Office empfiehlt sich das TTF-Format.

Web / Selbsthosting
-------------------
Auf dem Markenportal wird die Variable Font (InterVariable.woff2 +
InterVariable-Italic.woff2) selbst gehostet — sie deckt alle Gewichte ab.

Quelle & Updates
----------------
Inter ist frei und quelloffen: https://rsms.me/inter/
(auch über Google Fonts verfügbar)

Lizenz
------
SIL Open Font License 1.1 — siehe OFL.txt. Frei verwendbar, auch kommerziell;
Verkauf der Schrift selbst ist nicht gestattet.
